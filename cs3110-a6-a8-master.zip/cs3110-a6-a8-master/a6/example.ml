open Board

let example1 = [[(0,1);(0,2);(0,3)]; [(6,4);(6,5);(6,6);(6,7)]; [(9,8);(9,9)]]

let example2 = [[(0,1);(0,2);(0,3);(0,4)]; [(4,5);(5,5);(6,5)]; [(8,8)]; [(7,1);(7,2)];
                [(9,4);(9,5);(9,6)]; [(3,9);(4,9);(5,9)]]

let example3 = [[(0,1);(0,2);(0,3)]]

let example4 = [[(0,1);(0,2);(0,3);(0,4)]; [(4,5);(5,5);(6,5)]; [(8,8)]; [(7,1);(7,2)];
                [(9,4);(9,5);(9,6);(9,7);(9,8)]; [(3,9);(4,9);(5,9);(6,9)]]

let exampleBoards1 = [(Board.init 10 example2);(Board.init 10 example1)]

let config_A = [2;2;3;4;5]
(* 
let config_B = [3;4;5;5;1;1]

let config_C = [2;3;4;5] *)

(*putting this here for easily copy and pasting some ships for human player
  place (0,0) (0,0)
  place (1,0) (1,1)
  place (3,0) (3,2)
  place (5,4) (5,7)
  place (6,2) (6,6)
*)