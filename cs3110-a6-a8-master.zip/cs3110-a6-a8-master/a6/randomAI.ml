open Board
open Player 
open Command 

type t = Player.t

let init (name:string) (board: Board.t) (p_type: Player.p_type) (cannons:int) (radars: int): t =
  Player.init name board p_type cannons radars

let get_name p = 
  Player.get_name p

let get_board p =
  Player.get_board p

let get_type p = 
  Player.get_type

let set_opponent p o : t list = 
  Player.set_opponent p o

let update_board p b : t = 
  update_board p b 

let move (b:Board.t) : (int*int) = 
  let n = Board.size b in 
  (Random.int n,Random.int n)

let select_hit (c:(int*int)) (b:Board.t) (p:Player.t) : Command.t option = 
  let size = Board.size b in 
  let n = (Random.int size) in 
  if n <> (size/10) && Player.get_cannons p > 0 then (print_endline "\nYou used a cannon!"; Some (Cannon c)) 
  else Some (Hit c)

