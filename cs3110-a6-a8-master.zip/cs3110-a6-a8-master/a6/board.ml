type ship = {coords: (int*int) list;
             hit: (int*int) list;
             sunk: bool;
             score: int}

type t = {board: string array array;
          ships: ship list}

(** [make_ships ships acc] takes in a list of ships that have a list of
    corresponding coordinates that make up the ship and makes a new ship object
    with initial values of hit, sunk, and score that is then stored into a new
    list. *)
let rec make_ships (ships: (int*int) list list) (acc:ship list): ship list =
  match ships with
  |[] -> acc
  |ship::t -> make_ships t ({coords = ship;hit = [];sunk = false;score = (List.length ship)}::acc)

let init (n:int) (ships:(int*int) list list) : t =
  let board = Array.make_matrix n n "o" in
  let ship = make_ships ships [] in
  {board = board;ships = ship}

(** [is_sunk ship] returns true if the ship is sunk and false otherwise. *)
let rec is_sunk (ship: ship) : bool =
  if (List.length ship.coords) = (List.length ship.hit) then true
  else false

(** [is_hit coord ships] returns a boolean of whether the coordinate hit a ship
    that has not yet been hit. *)
let rec is_hit (coord: (int*int)) (ships: ship list) : bool =
  match ships with
  |[] -> false
  |h::t -> let hits = List.fold_left (fun acc e -> if e = coord then e::acc else acc) [] h.coords in
    if hits = [] then is_hit coord t
    else true

(** [check_hit c b] is true if the coordinate hit is a ship that has not yet
    been hit, false otherwise. *)
let check_hit c b =
  is_hit c b.ships


(** [edit_ships coord ships acc] returns a new ship list where the ship that was
    hit is updated with the coordinate it was hit on. *)
let rec edit_ships (coord: (int*int)) (ships:ship list) (acc:ship list): ship list =
  match ships with
  |[] -> acc
  |h::t -> let hits = List.fold_left (fun acc e -> if e = coord then e::acc else acc) [] h.coords in
    if hits = [] then edit_ships coord t (h::acc)
    else (if is_sunk {h with hit = h.hit@hits} then edit_ships coord t ({h with hit = h.hit@hits;sunk = true}::acc)
          else edit_ships coord t ({h with hit = h.hit@hits}::acc))

(** [get_ship coord ships] is Some x where x is the ship in [ships] that
    has coordinate [coord] in it, and None if none of the ships in [ships]
    have [coord] in them. *)
let rec get_ship (coord) (ships) =
  match ships with
  | [] -> None
  | x::t-> if List.mem coord x.coords then Some x else get_ship coord t

(** [sink_ship coords board] edits [board] so that all the [coords] in [board]
    are represented as sunk. *)
let rec sink_ship coords board =
  match coords with
  | [] -> ()
  | (x,y)::t -> board.(x).(y) <- "s"; sink_ship t board

let hit (coord: (int*int)) (b:t) : t =
  let ships = edit_ships coord b.ships [] in
  match coord with
  | x,y -> if (is_hit coord b.ships) = false then b.board.(x).(y) <- "x"
    else begin
      match (get_ship coord ships) with
      | None -> ()
      | Some z -> if z.sunk then sink_ship z.coords b.board else b.board.(x).(y) <- "h" end;
    {board = b.board; ships = ships}

(** [print_list lst] prints out a list that contains tuples. *)
let rec print_list lst : unit =
  match lst with
  |[] -> print_string "";
  |h::t -> print_string "("; match h with |x,y -> print_int x;print_string ","; print_int y;print_string "), ";print_list t

(** [win_helper ships] checks to see that every ship in the list of ships is sunk. *)
let rec win_helper ships =
  match ships with
  | [] -> true
  | h::t -> if h.sunk = true then win_helper t else false

let win bd = win_helper bd.ships

let coords_to_list (b:t) : (int*int) list list =
  let rec coordsHelper (ships:ship list) (acc:(int*int) list list) : (int*int) list list =
    match ships with
    |[] -> acc
    |h::t -> coordsHelper t (h.coords::acc) in
  coordsHelper b.ships []

let hits_to_list (b:t) : (int*int) list list =
  let rec hitsHelper (ships:ship list) (acc:(int*int) list list) : (int*int) list list =
    match ships with
    |[] -> acc
    |h::t -> hitsHelper t (h.hit::acc) in
  hitsHelper b.ships []

(** [print_out_line str] prints out a line of board data,
    coloring as appropriate.
    Raises: Failure if invalid characters in line.
*)
let rec print_out_line str =
  if (str = "") then ()
  else
    ((
      let char = String.sub str 0 3 in
      if (char = " o ") then ANSITerminal.(print_string [black;on_cyan] char)
      else if (char = " h ") then ANSITerminal.(print_string [black;on_yellow] char)
      else if (char = " s ") then ANSITerminal.(print_string [white;on_red] char)
      else if (char = " x ") then ANSITerminal.(print_string [black; on_default] char)
      else if (char = " * ") then ANSITerminal.(print_string [black; on_magenta] char)
      else if (char = " ~ ") then ANSITerminal.(print_string [black; on_magenta] char)
      else failwith "Invalid string"

    ); print_out_line (String.sub str 3 (String.length str - 3))
    )

(** [through_board board] prints out the board in an orderly fashion to represent
    the matrix. *)
let rec through_board (board: string array array) =
  Array.fold_left (
    fun acc n ->
      let spacing = (if acc < 10 then " " else "") in
      ANSITerminal.(print_string [black;on_white] ((string_of_int acc)^spacing));
      (*need extra space btwn numbers + board*)
      ANSITerminal.(print_string [black;on_white] " ");
      let line_str = ((Array.fold_left (fun x y -> x^"  "^y) ""  n)^" ") in
      print_out_line (String.sub line_str 1 (String.length line_str - 1));
      ANSITerminal.(print_string [black] "\n");
      acc+1) 0 board

let print_board_lst lst =
  let output = (" "^
                (List.fold_left (fun x y ->
                     let spacing = (if y <= 10 then "  " else " ") in
                     x^spacing^(string_of_int y)) " "
                    (List.init (Array.length lst) (fun x -> x)))
               ) in
  ANSITerminal.(print_string [black;on_white] output);
  ANSITerminal.(print_string [black] "\n"); (*create new line*)
  ignore (through_board lst)

let print_board bd =
  print_board_lst bd.board

let board_to_list t =
  Array.to_list (Array.map (fun x -> Array.to_list x ) t.board)

let score (b:t) : int =
  let rec scoreHelper (ships: ship list) (acc:int) : int =
    match ships with
    |[] -> acc
    |h::t -> if h.sunk = true then scoreHelper t (h.score+acc)
      else scoreHelper t acc in
  scoreHelper b.ships 0
(** Specifically to show where the user placed their ships. *)
let make_print_board (h: (int*int) list list) n =
  let board = Array.make_matrix n n "o" in
  let rec add_ships ship =
    match ship with
    | [] -> ()
    | (x,y)::t -> board.(x).(y) <- "s"; add_ships t
  in ignore (List.map (fun x -> add_ships x) h); board

(** [size b] returns the length of one side of the board. Since the board is
    always square it doesn't matter which side. *)
let size b =
  Array.length b.board

let rec hitsToAcc (hits:(int*int) list) (acc:(int*int) list) : (int*int) list =
  match hits with
  |[] -> acc
  |h::t -> if List.mem h acc then hitsToAcc t acc
    else hitsToAcc t (h::acc)

(** [get_AI_hits] returns all the coordinates that have been hit excluding ones
    that have been sunk. *)
let get_AI_hits (b:t) : (int*int) list =
  let rec getHitsHelper (ships:ship list) (acc:(int*int) list) : (int*int) list =
    match ships with
    |[] -> acc
    |h::t -> if is_sunk h then getHitsHelper t acc
      else getHitsHelper t (hitsToAcc (h.hit) acc) in
  getHitsHelper b.ships []

(** [valid_guess c b] returns true if coordinate [c] is not a coordinate that has
    been hit yet, returns false otherwise. *)
let valid_guess (c:(int*int)) (b:t) : bool =
  match c with
  |x,y -> if x >=0 && x < (size b) && y >=0 && y < (size b) then
      if b.board.(x).(y) = "o" then true
      else false
    else false

(** [check_color_even boards even index accumulator] assumes the board is a
    checkerboard and looks at all black squares that are in the even rows to see
    if it has a coordinate that has been hit. *)
let rec check_color_even (boards:t) even index (accumulator:int) =
  if index < (size boards) then if (boards.board.(even).(index) = "h" ||
                                    boards.board.(even).(index) = "x" || boards.board.(even).(index) = "s")
    then check_color_even boards (even) (index+2) (accumulator+1) else
      (check_color_even (boards) (even) (index+2) (accumulator)) else if (even < (size boards)-2)
  then check_color_even boards (even+2) (0) (accumulator) else accumulator

(** [check_color_odd boards even index accumulator] assumes the board is a
    checkerboard and looks at all black squares that are in the odd rows to see
    if it has a coordinate that has been hit. *)
let rec check_color_odd (boards:t) odd index (accumulator:int) =
  if index < (size boards) then if (boards.board.(odd).(index) = "h" ||
                                    boards.board.(odd).(index) = "x" || boards.board.(odd).(index) = "s")
    then check_color_odd boards (odd) (index+2) (accumulator+1) else
      (check_color_odd boards (odd) (index+2) (accumulator)) else if (odd < (size boards)-2)
  then check_color_odd boards (odd+2) (1) accumulator else accumulator

(**[in_bounds c size] is true if [c] is in bounds on board with [size]*)
let in_bounds (c:(int*int)) (size:int) : bool =
  match c with
  |x,y -> if x >=0 && x < size && y >=0 && y < size then true
    else false

let rec make_cannon_list (c:(int*int)) : (int*int) list =
  match c with |x,y ->
    (x-1,y-1)::(x-1,y)::(x-1,y+1)::(x,y-1)::(x,y)::(x,y+1)::(x+1,y-1)::(x+1,y)::(x+1,y+1)::[]

let cannon_hit (c:(int*int)) (b:t) : t =
  let coords = make_cannon_list c in
  let size = size b in
  let rec cannon_helper (cannon:(int*int) list) (board:t) : t =
    match cannon with
    |[] -> board
    |h::t -> if (in_bounds h size) then cannon_helper t (hit h board)
      else cannon_helper t board in
  cannon_helper coords b

let check_cannon_hit c b : bool =
  let coords = make_cannon_list c in
  let rec check_cannon_helper (cannon:(int*int) list) : bool =
    match cannon with
    |[] -> false
    |h::t -> if is_hit h b.ships then true
      else check_cannon_helper t in
  check_cannon_helper coords

(**[valid_coords (x,y) size] is the coordinates surroundinng [(x,y)] (3x3 grid)
   that are in the board with [size]*)
let valid_coords (x,y) size =
  let square = [(x+1, y-1); (x+1, y); (x+1, y+1); (x, y-1); (x, y); (x, y+1); (x-1, y-1); (x-1, y); (x-1, y+1)] in
  List.filter (fun (x,y) -> x >= 0 && x < size && y >= 0 && y < size) square

(**[radar_edit bd ships coords] edits [bd] to show the ships [ships] with radar range at [coords]*)
let rec radar_edit (bd: string array array) (ships: (int*int) list) (coords: (int*int) list)=
  match coords with
  | [] -> ()
  | (a,b)::t -> if bd.(a).(b) = "o" then begin
      if (List.mem (a,b) ships) then bd.(a).(b) <- "*" else bd.(a).(b) <- "~" end;
    radar_edit bd ships t

(**[flatten_ships ships acc] is [acc] with all the coordinates in of ships in [ships]
   added to it*)
let rec flatten_ships (ships: ship list) (acc) =
  match ships with
  | [] -> acc
  | h::t -> flatten_ships t (h.coords@acc)

let print_radar t coord =
  let b = Array.copy t.board in
  let b2 = Array.map (fun x -> Array.copy x) b in
  radar_edit b2 (flatten_ships t.ships []) (valid_coords coord (Array.length b));
  print_board_lst b2
