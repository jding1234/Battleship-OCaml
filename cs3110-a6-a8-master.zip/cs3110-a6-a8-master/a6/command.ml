
type coord = int * int

type t =
  | Place of (coord*coord)
  | Hit of coord
  | Cannon of coord
  | Radar of coord
  | Score
  | Quit

exception BadCommand of string
exception InvalidCoordList of (coord * coord)

(** [get_str_list_helper str curr l] takes in a string version of a command
    and outputs a list of non-empty strings in [str].
    Requires: l is empty list, curr = "". *)
let rec get_str_list_helper str curr l =
  (*Check if we're done with the string*)
  if (str = "")
  then (if (String.length curr > 0) then (l@[curr]) else l)
  else
    (*Get the next character in the string*)
    let fst = String.sub str 0 1 in
    let rest = String.sub str 1 (String.length str - 1) in
    match fst with
    | " " -> (
        if (String.length curr > 0)
        then (get_str_list_helper rest "" (l@[curr]))
        else (get_str_list_helper rest curr l)
      )
    | x -> get_str_list_helper rest (curr^x) l

(** [get_str_list str] returns a list of the strings in [str], where
    each string is separated by at least one space. *)
let get_str_list str =
  get_str_list_helper str "" []

(** [parse_coord str] translates a string representation of a coordinate
    to a coordinate object.
    Raises: BadCommand if str not in the form (int,int).
*)
let parse_coord str =
  (*valid coordinate ex: (3,4) or (10,3) or (12,12).*)
  try (
    let fst = String.sub str 0 1 in
    let last = String.sub str (String.length str - 1) 1 in

    (*Check valid representation of a coordinate*)
    if (fst = "(" && last = ")")
    then (
      (*try to build a coordinate *)
      let comma = String.index str ',' in
      let int1 = (String.sub str 1 (comma - 1)) |> int_of_string in
      let int2 = (String.sub str (comma+1) ((String.length str) - comma -2)) |> int_of_string in
        (int1,int2)
    )
    else (3,4)
  ) with
  | e -> (5,6)

(** [parse_coords_place l] takes in a list of coordinate strings [l] and
    outputs a tuple of the respective coordinates.
    Requires: l is a list of length two, each element is a valid coordinate string
    (non-negative, in form "(3,4)").
*)
let parse_coords_place l =
  match l with
  | str1::str2::[] -> (
      let fst = parse_coord str1 in
      let snd = parse_coord str2 in
      (fst,snd)
    )
  | _ -> raise (BadCommand "Invalid coordinate list")

(** [check_coord_list_rep l] returns the tuple represented by l
    if the tuple is a valid set of coordinates, or raises exception.
    RI: A coordinate pair is valid if the resulting line is parallel
        to either the x or y axis - cannot be diagonal.
        Also, the points cannot be identical.
    Raises: InvalidCoordList if invalid coordinates.
*)
let check_coord_list_rep (l:coord*coord):(coord*coord) =
  match l with
  | ((x1,y1),(x2,y2)) -> (
      (*A coordinate pair is valid if the resulting line is parallel
        to either the x or y axis - cannot be diagonal.
        Also, the points CAN be identical*)
      if ((x1 = x2 && y1 <> y2) || (x1 <> x2 && y1 == y2) || x1 = x2 && y1=y2)
      then l
      else raise (InvalidCoordList l)
    )

let parse str =
  match ( str |> String.lowercase_ascii |> get_str_list )with
  | "place"::t  -> (
      Place (t |> parse_coords_place |> check_coord_list_rep)
    )
  | "hit"::str1::[] -> (
      Hit (parse_coord str1)
    )
  | "cannon"::str1::[] -> (
      Cannon (parse_coord str1)
    )
  | "radar"::str1::[] -> (Radar (parse_coord str1))
  | "score"::t -> if (t = []) then (Score) else raise (BadCommand str )
  | "quit"::t -> if (t = []) then (Quit) else raise (BadCommand str )
  | _ -> raise (BadCommand str )
