open Example
open Board
open OUnit2
open Main

(*-------------------------BOARD TESTS----------------------------*)
(* ---------------Printing purposes-------------- *)

(** [rowToString r] takes in the string [r], which is a row in the matrix,
    and converts it to list of tuples where the parenthesis are printed out 
    in order to help with comprehensiblity. *)
let rec rowToString r =
  match r with
  | [] -> ""
  | (x,y) :: t -> "(" ^ (string_of_int x) ^ "," ^ (string_of_int y) ^ ")" ^ 
    (rowToString t)

(** [matrixToString i] prints out every single row of the matrix. *)
let rec matrixToString i =
  match i with
  | [] -> ""
  | h::[] -> "[" ^ (rowToString h) ^ "]"
  | h :: t -> "[" ^ (rowToString h) ^ "];\n" ^ (matrixToString t)

(** [pp_my_image s] takes in the string that is a (int * int) list list and
    converts it to a printable string. *)
let pp_my_image s =
  "\n" ^ matrixToString s

(** [stringRowToString r] takes in the string [r], which is a row in the matrix,
    and converts it to list of tuples where the parenthesis are printed out 
    in order to help with comprehensiblity. *)
let rec stringRowToString r =
  match r with
  | [] -> ""
  | h::[] -> (h)
  | h :: t -> (h) ^ ";" ^ (stringRowToString t)

(** [stringMatrixToString i] prints out every single row of the matrix. *)
let rec stringMatrixToString i =
  match i with
  | [] -> ""
  | h::[] -> "[" ^ (stringRowToString h) ^ "]"
  | h :: t -> "[" ^ (stringRowToString h) ^ "];\n" ^ (stringMatrixToString t)

(** [string_pp_my_image s] takes in the string that is a string list list and
    converts it to a printable string. *)
let string_pp_my_image s =
  "\n" ^ stringMatrixToString s

(* ---------------Printing purposes--------------- *)

(** [make_to_coords_test name board expected_output] constructs an OUnit
    test named [name] that asserts the quality of [expected_output]
    with [coords_to_list board]. *)
let make_to_coords_test
    (name : string)
    (board : Board.t)
    (expected_output : (int*int) list list) : test =
  name >:: (fun _ ->
      assert_equal expected_output (coords_to_list board)~printer: pp_my_image)

(** [make_to_hits_test name board expected_output] constructs an OUnit
    test named [name] that asserts the quality of [expected_output]
    with [hits_to_list board]. *)
let make_to_hits_test
    (name : string)
    (board : Board.t)
    (expected_output : (int*int) list list) : test =
  name >:: (fun _ ->
      assert_equal expected_output (hits_to_list board)~printer: pp_my_image)

(** [make_to_board_test name board expected_output] constructs an OUnit
    test named [name] that asserts the quality of [expected_output]
    with [board_to_list board]. *)
let make_to_board_test
    (name : string)
    (board : Board.t)
    (expected_output : string list list) : test =
  name >:: (fun _ ->
      assert_equal expected_output (board_to_list board)~printer: 
        string_pp_my_image)

(** [make_checkhit_test name coordinate board expected_output] constructs an OUnit
    test named [name] that asserts the quality of [expected_output]
    with [check_hit coordinate board]. *)
let make_checkhit_test
    (name : string)
    (coordinate: (int*int))
    (board: Board.t)
    (expected_output : bool) : test =
  name >:: (fun _ ->
      assert_equal expected_output (check_hit coordinate board))

(** [make_win_test name board expected_output] constructs an OUnit
    test named [name] that asserts the quality of [expected_output]
    with [win board]. *)
let make_win_test
    (name : string)
    (board : Board.t)
    (expected_output : bool) : test =
  name >:: (fun _ ->
      assert_equal expected_output (win board))

let make_start_test
    (name : string)
    (coord1 : int*int)
    (coord2 : int*int)
    (expected_output : (int*int) list) : test =
  name >:: (fun _ ->
      assert_equal expected_output (start_end_lst coord1 coord2))
      
let make_place_test
    (name : string)
    (board : Board.t)
    (expected_output : bool) : test =
  name >:: (fun _ ->
      assert_equal expected_output (win board))

(** [make_valid_test name ship track expected_output] constructs an OUnit
    test named [name] that asserts the quality of [expected_output]
    with [is_valid_ship ship track]. *)
let make_valid_test
    (name : string)
    (ship: (int * int) list)
    (track : (int * int) list list)
    (expected_output : bool) : test =
  name >:: (fun _ ->
      assert_equal expected_output (is_valid_ship ship track ))

let board1 = init 10 example1
let board2 = init 10 example2
let board3 = init 10 example3
let board21 = hit (0,0) board2
let board4 = init 10 example2
let board22 = hit (0,1) board4

let winboard = init 10 [[(0,0)]]
let winboard2 = hit(6,6) (hit(6,7) (hit (6,5) (hit (6,4) (hit (0,1) (hit (0,2) 
  (hit (0,3) (init 10 example1)))))))
let board_tests =
  [
    (* --- init tests --- *)
    make_valid_test "Valid Ship 1" [(0,1);(0,2)] [[(0,5);(0,6)];[(0,2)]] false;
    make_valid_test "Valid Ship 2" [(0,1);(0,2)] [[(0,5);(0,6)];[(0,3)]] true;
    make_valid_test "Valid Ship 3" [(0,1);(0,2);(0,3)] [[(0,5);(0,6)];[(0,3)]] false;
    make_valid_test "Valid Ship 4" [(0,1);(0,2);(0,7)] [[(0,5);(0,6)];[(0,3)]] true;
    make_valid_test "Valid Ship 5" [(0,1);(0,2);(0,0);(1,0)] [[(0,5);(0,6)];[(0,3)]] true;
    make_valid_test "Valid Ship 6" [(0,1);(0,2);(0,0)] [[(0,5);(0,6)];[(0,3)]] true;
    make_valid_test "Valid Ship 7" [(0,1);(0,2);(0,0)] [[(0,5);(0,6)];[(0,3)];[(0,0)]] false;
    make_valid_test "Valid Ship 8" [(0,1);(0,2);(0,0)] [[(0,5);(0,6)];[(0,3)];[(0,7)]] true;
    
    make_start_test "Start to End 1" (0,1) (0,5) [(0,1);(0,2);(0,3);(0,4);(0,5)];
    make_start_test "Start to End 2" (1,0) (5,0) [(1,0);(2,0);(3,0);(4,0);(5,0)];
    make_start_test "Start to End 3" (2,1) (2,1) [(2,1)];
    make_start_test "Start to End 4" (10,9) (10,9) [(10,9)];
    make_start_test "Start to End 5" (1,9) (1,1) [(1,1);(1,2);(1,3);(1,4);(1,5);(1,6);(1,7);(1,8);(1,9)];
    make_start_test "Start to End 6" (7,9) (5,9) [(5,9);(6,9);(7,9)];
    
    make_to_coords_test "init1shipcoords" board1 [[(0,1);(0,2);(0,3)]; 
      [(6,4);(6,5);(6,6);(6,7)]; [(9,8);(9,9)]];
    make_to_coords_test "init2shipcoords" board2 [[(0,1);(0,2);(0,3);(0,4)]; 
      [(4,5);(5,5);(6,5)]; [(8,8)]; [(7,1);(7,2)]; [(9,4);(9,5);(9,6)]; 
      [(3,9);(4,9);(5,9)]];
    make_to_coords_test "init3shipcoords" board3 [[(0,1);(0,2);(0,3)]];
    (*ADD INIT TESTS FOR EXAMPLE 2 HERE*)

    make_to_board_test "init1board" board1
      [["o";"o";"o"; "o";"o";"o"; "o";"o";"o";"o"];
       ["o";"o";"o"; "o";"o";"o"; "o";"o";"o";"o"];
       ["o";"o";"o"; "o";"o";"o"; "o";"o";"o";"o"];
       ["o";"o";"o"; "o";"o";"o"; "o";"o";"o";"o"];
       ["o";"o";"o"; "o";"o";"o"; "o";"o";"o";"o"];
       ["o";"o";"o"; "o";"o";"o"; "o";"o";"o";"o"];
       ["o";"o";"o"; "o";"o";"o"; "o";"o";"o";"o"];
       ["o";"o";"o"; "o";"o";"o"; "o";"o";"o";"o"];
       ["o";"o";"o"; "o";"o";"o"; "o";"o";"o";"o"];
       ["o";"o";"o"; "o";"o";"o"; "o";"o";"o";"o"]];
    make_to_board_test "hit1board" (hit (0,1) (init 10 example1))
      [["o";"h";"o"; "o";"o";"o"; "o";"o";"o";"o"];
       ["o";"o";"o"; "o";"o";"o"; "o";"o";"o";"o"];
       ["o";"o";"o"; "o";"o";"o"; "o";"o";"o";"o"];
       ["o";"o";"o"; "o";"o";"o"; "o";"o";"o";"o"];
       ["o";"o";"o"; "o";"o";"o"; "o";"o";"o";"o"];
       ["o";"o";"o"; "o";"o";"o"; "o";"o";"o";"o"];
       ["o";"o";"o"; "o";"o";"o"; "o";"o";"o";"o"];
       ["o";"o";"o"; "o";"o";"o"; "o";"o";"o";"o"];
       ["o";"o";"o"; "o";"o";"o"; "o";"o";"o";"o"];
       ["o";"o";"o"; "o";"o";"o"; "o";"o";"o";"o"]];
    make_to_board_test "hit2board" (hit (4,2) (init 10 example1))
      [["o";"o";"o"; "o";"o";"o"; "o";"o";"o";"o"];
       ["o";"o";"o"; "o";"o";"o"; "o";"o";"o";"o"];
       ["o";"o";"o"; "o";"o";"o"; "o";"o";"o";"o"];
       ["o";"o";"o"; "o";"o";"o"; "o";"o";"o";"o"];
       ["o";"o";"x"; "o";"o";"o"; "o";"o";"o";"o"];
       ["o";"o";"o"; "o";"o";"o"; "o";"o";"o";"o"];
       ["o";"o";"o"; "o";"o";"o"; "o";"o";"o";"o"];
       ["o";"o";"o"; "o";"o";"o"; "o";"o";"o";"o"];
       ["o";"o";"o"; "o";"o";"o"; "o";"o";"o";"o"];
       ["o";"o";"o"; "o";"o";"o"; "o";"o";"o";"o"]];
    make_to_board_test "hit3board" (hit (4,2) (hit (0,1) (init 10 example1)))
      [["o";"h";"o"; "o";"o";"o"; "o";"o";"o";"o"];
       ["o";"o";"o"; "o";"o";"o"; "o";"o";"o";"o"];
       ["o";"o";"o"; "o";"o";"o"; "o";"o";"o";"o"];
       ["o";"o";"o"; "o";"o";"o"; "o";"o";"o";"o"];
       ["o";"o";"x"; "o";"o";"o"; "o";"o";"o";"o"];
       ["o";"o";"o"; "o";"o";"o"; "o";"o";"o";"o"];
       ["o";"o";"o"; "o";"o";"o"; "o";"o";"o";"o"];
       ["o";"o";"o"; "o";"o";"o"; "o";"o";"o";"o"];
       ["o";"o";"o"; "o";"o";"o"; "o";"o";"o";"o"];
       ["o";"o";"o"; "o";"o";"o"; "o";"o";"o";"o"]];
    make_to_board_test "hit4board" board21
      [["x";"o";"o"; "o";"o";"o"; "o";"o";"o";"o"];
       ["o";"o";"o"; "o";"o";"o"; "o";"o";"o";"o"];
       ["o";"o";"o"; "o";"o";"o"; "o";"o";"o";"o"];
       ["o";"o";"o"; "o";"o";"o"; "o";"o";"o";"o"];
       ["o";"o";"o"; "o";"o";"o"; "o";"o";"o";"o"];
       ["o";"o";"o"; "o";"o";"o"; "o";"o";"o";"o"];
       ["o";"o";"o"; "o";"o";"o"; "o";"o";"o";"o"];
       ["o";"o";"o"; "o";"o";"o"; "o";"o";"o";"o"];
       ["o";"o";"o"; "o";"o";"o"; "o";"o";"o";"o"];
       ["o";"o";"o"; "o";"o";"o"; "o";"o";"o";"o"]];
    make_to_board_test "hit5board" board22
      [["o";"h";"o"; "o";"o";"o"; "o";"o";"o";"o"];
       ["o";"o";"o"; "o";"o";"o"; "o";"o";"o";"o"];
       ["o";"o";"o"; "o";"o";"o"; "o";"o";"o";"o"];
       ["o";"o";"o"; "o";"o";"o"; "o";"o";"o";"o"];
       ["o";"o";"o"; "o";"o";"o"; "o";"o";"o";"o"];
       ["o";"o";"o"; "o";"o";"o"; "o";"o";"o";"o"];
       ["o";"o";"o"; "o";"o";"o"; "o";"o";"o";"o"];
       ["o";"o";"o"; "o";"o";"o"; "o";"o";"o";"o"];
       ["o";"o";"o"; "o";"o";"o"; "o";"o";"o";"o"];
       ["o";"o";"o"; "o";"o";"o"; "o";"o";"o";"o"]];

    make_checkhit_test "checkhit1board" (0,1) (hit (0,1) (init 10 example1)) 
      true;
    make_checkhit_test "checkhit2board" (0,5) (hit (0,1) (init 10 example1)) 
      false;
    make_checkhit_test "checkhit3board" (0,6) (hit (0,1) (init 10 example1)) 
      false;
    make_checkhit_test "checkhit4board" (0,3) (hit (0,3) (hit (0,1) 
      (init 10 example1))) true;
    make_checkhit_test "checkhit4board" (0,1) (hit (0,3) (hit (0,1) 
      (init 10 example1))) true;
    (* Should still return false because (0,7) is not a ship coordinate *)
    make_checkhit_test "checkhit5board" (0,7) (hit (0,7) (hit (0,1) 
      (init 10 example1))) false;
    make_checkhit_test "checkhit6board" (0,8) (hit (0,1) (init 10 example1)) 
      false;
    make_checkhit_test "checkhit7board" (0,9) (hit (0,1) (init 10 example1)) 
      false;

    (*----hit tests----*)
    make_to_hits_test "hit1hitscoords" board21 [[];[];[];[];[];[]];
    make_to_hits_test "init1hitscoords" board1 [[]; []; []];
    make_to_hits_test "init2hitscoords" board21 [[]; []; []; []; []; []];
    make_to_hits_test "init3hitscoords" board2 [[]; []; []; []; []; []];
    make_to_hits_test "init4hitscoords" board3 [[]];
    make_to_hits_test "init5hitscoords" board22 [[]; []; []; []; []; [(0,1)]];
    make_to_hits_test "init6hitscoords" board3 [[]];
    make_to_hits_test "init7hitscoords" board3 [[]];
    make_to_hits_test "init8hitscoords" (hit (0,2) (hit (0,1) (init 10 example2))) 
      [[(0,1);(0,2)]; []; []; []; []; []];
    (* Order of hit list keeps on switching after each call to hit *)
    make_to_hits_test "init9hitscoords" (hit (8,8) (hit (0,2) (hit (0,1) 
      (init 10 example2)))) [[]; []; []; [(8,8)]; []; [(0,1);(0,2)]];
    make_to_hits_test "init10hitscoords" board22 [[]; []; []; []; []; [(0,1)]];
    (*ADD HITS TESTS HERE, MAKE SURE TO TEST WHEN HITS SHIP*)

    (*----win tests----*)
    make_win_test "winTest1" board1 false;
    make_win_test "wintest1" (hit (0,0) winboard) true;
    make_win_test "wintest2" (hit(6,6) (hit(6,7) (hit (6,5) (hit (6,4) 
      (hit (0,1) (hit (0,2) (hit (0,3) (init 10 example1)))))))) false;
    make_win_test "wintest3" (hit (9,8) (hit (9,9) (winboard2))) true;
    make_win_test "wintest4" (hit (0,0) (hit (9,9) (winboard2))) false;
    (*ADD WIN TESTS HERE*)
  ]

(*-------------------------end BOARD TESTS end---------------------------*)
(*-------------------------COMMAND TESTS----------------------------*)
open Command
(*Variables for parse tests *)
let place_row = "place (3,1) (4,1)"
let place_col = "place (3,1) (3,2)"
let place_dup = "place (3,1) (3,1)"
let place_diag = "place (3,1) (4,2)"
let place_too_few = "place (3,1)"
let place_too_many = "place (4,1) (4,2) (4,3)"
let place_inv1 = "place foobar"
let place_inv2 = "place (33)"
let place_inv3 = "place (foo,bar)"
let place_empty = "place "
let hit = "hit (3,2)"
let hit_empty = "hit"
let hit_inv1 = "hit ship"
let hit_inv2 = "hit -1"
let score = "score"
let score_inv = "score the game"
let quit = "quit"
let quit_inv = "quit the game"

(** [make_parse_test name input expected_output] constructs an OUnit
    test named [name] that asserts the quality of [expected_output]
    with [parse input]. *)
let make_parse_test name input expected_output =
  name >:: (fun _ -> assert_equal expected_output (parse input))

(** [make_parse_test name input ex] constructs an OUnit
    test named [name] that asserts [parse input] raises [ex]. *)
let make_parse_exn_test name input ex =
  name >:: (fun _ -> assert_raises ex (fun () -> parse input))

let command_tests =
  [
    make_parse_test "Parse: place row" place_row (Place ((3,1),(4,1)));
    make_parse_test "Parse: place col" place_col (Place ((3,1),(3,2)));
    make_parse_test "Parse: place duplicate" place_dup (Place ((3,1),(3,1)));
    make_parse_exn_test "Parse: place diagonal" place_diag (InvalidCoordList ((3,1),(4,2)));
    make_parse_exn_test "Parse: place too few" place_too_few (BadCommand "Invalid coordinate list");
    make_parse_exn_test "Parse: place too many" place_too_many (BadCommand "Invalid coordinate list");
    make_parse_exn_test "Parse: place inv1" place_inv1 (BadCommand "Invalid coordinate list");
    make_parse_exn_test "Parse: place inv2" place_inv2 (BadCommand "Invalid coordinate list");
    make_parse_exn_test "Parse: place inv3" place_inv3 (BadCommand "Invalid coordinate list");
    make_parse_exn_test "Parse: place empty" place_empty (BadCommand "Invalid coordinate list");

  ]
(*-------------------------end COMMAND TESTS end---------------------------*)
let suite =
  "test suite for battleship"  >::: List.flatten [
    board_tests;
    command_tests;
  ]

let _ = run_test_tt_main suite
