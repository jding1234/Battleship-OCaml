open Board
open Player 

type t = Player.t

let init (name:string) (board: Board.t) (p_type: Player.p_type) (cannons:int) (radars:int) : t =
  Player.init name board p_type cannons radars

let get_name p = 
  Player.get_name p

let get_board p =
  Player.get_board p

let get_type p = 
  Player.get_type

let set_opponent p o : t list = 
  Player.set_opponent p o

let update_board p b : t = 
  update_board p b 

(** [moveHelper n coords b] takes in a board size, list of coordinates, and the
    current board and allows for a smart CPU that looks at the current list of
    coordinates that have been hit and makes educated guesses on where to hit next.
    It does so by looking at a coordinate that has hit a ship and then trying all
    coordinates immediately next to it. *)
let rec moveHelper (n:int) (coords:(int*int) list) (b:Board.t) : (int*int) = 
  match coords with 
  |[] -> (Random.int n,Random.int n)
  |h::t -> match h with |x,y -> if valid_guess (x+1,y) b then (x+1,y)
    else if valid_guess (x-1,y) b then (x-1,y)
    else if valid_guess (x,y+1) b then (x,y+1)
    else if valid_guess (x,y-1) b then (x,y-1)
    else moveHelper n t b

(** [random_until_valid n b] takes in the board size and a board and selects
    a random coordinate to hit if it has not been hit yet. *)
let rec random_until_valid (n:int) (b:Board.t) : (int*int) = 
  let c = (Random.int n,Random.int n) in
  if (valid_guess c b = true && fst c mod 2 = 0 && snd c mod 2 = 0) || 
     (valid_guess c b = true && fst c mod 2 = 1 && snd c mod 2 = 1) then c else
    (if valid_guess c b && (((Board.check_color_even b 0 0 0) + 
                             (Board.check_color_odd b 1 1 0)) = (((size b)*(size b))/2)) then c
    (** Mathematical parity strategy, essentially if we imagine the board as a
        checkerboard, and we only choose to hit the white squares, we are bound
        to hit one of the ships, if we assume that they are all of length two or bigger.*)
     else random_until_valid n b)

let move (b:Board.t) : (int*int) = 
  let n = Board.size b in 
  let hits = Board.get_AI_hits b in 
  match hits with 
  |[] -> random_until_valid n b 
  |_ -> moveHelper n hits b 

let select_hit (c:(int*int)) (b:Board.t) (p:Player.t): Command.t option = 
  let size = Board.size b in 
  let n = (Random.int size) in 
  if n <> (size/3) && Player.get_cannons p > 0 then (print_endline "\nYou used a cannon!"; Some (Cannon c)) 
  else Some (Hit c)
