open Board


type p_type = Human | RandomAI | SmartAI | AdvancedAI

type t = {name: string; board: Board.t; p_type: p_type;cannons: int; radars: int}

let init (name:string) (board: Board.t) (p_type:p_type) (cannons:int) (radars: int): t =
  {name = name; board = board; p_type = p_type;cannons = cannons; radars = radars}

let get_name p = 
  p.name

let get_board p =
  p.board

let get_type p = 
  p.p_type

let get_cannons p = 
  p.cannons

let get_radars p = p.radars

let set_opponent p o : t list = 
  {p with board = o.board}::[{o with board = p.board}]

let update_board p b : t = 
  {p with board = b}

let dec_cannons p : t = 
  {p with cannons = p.cannons-1}

let dec_radar p : t = 
  { p with radars = p.radars - 1}