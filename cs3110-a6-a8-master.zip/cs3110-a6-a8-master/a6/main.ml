open Board
open Player
open Example
open Command
open RandomAI
open SmartAI
open AdvancedAI 

(**thrown when user quit's while assigning players names*)
exception Quit

(**defines the settings for the given game*)
type settings = {
  config: int list;
  size: int;
  cannons: int;
  radars: int;
}

(** Make sure when we make shit, that they dont overlap. *)

(** [is_valid_ship ship track] is true if the [ship] coordinates doesn't overlap
    with any coordinates in [track], false otherwise. *)
let is_valid_ship (ship: (int*int) list) (track: (int*int) list list) =
  let check_ships coord ships = List.fold_left (fun x y -> (not (List.mem coord y)) && x) true ships in
  List.fold_left (fun x y -> (check_ships y track) && x) true ship

(** [start_end_lst (x,y) (a,b)] is a list of the coordinates from [(x,y)]
    to [(a,b)]
    Requires:
    [(x,y)] and [(a,b)] form a line parallel to x or y axis. *)
let start_end_lst (x,y) (a,b) : (int*int) list=
  if x = a then List.init ((abs (y-b))+1) (fun z -> (a, (Pervasives.min y b)+ z)) else
    List.init ((abs (x-a))+1) (fun z -> ( (Pervasives.min x a)+ z), b)

(** [set_ship n size track] is a coordinate list of ship size [n] resulting from
    prompting the user for the start and end coordinates. The result is on board size [size]
    and doesn't overlap with any ships in [track].
    Raises:
    [Quit] if player chooses to quit. *)
let rec set_ship (n) (size) (track) : (int*int) list =
  Board.print_board_lst (Board.make_print_board track size);
  print_endline ("\nPlace ship of length "^(string_of_int n)^". Specify start and end coordinates as follows: place (r1,c1) (r2,c2).");
  print_string ("> ");
  match read_line() with
  (* | exception End_of_file -> print_endline "Not valid\n"; set_ship n size track *)
  | s -> begin match parse s with
      | exception InvalidCoordList x -> print_endline "Those coordinates are not in line. \n"; set_ship n size track
      | Quit -> raise Quit
      | Place ((x,y), (a,b)) ->
        if (x < 0 || x >= size) || (y < 0 || y >= size) || (a < 0 || a >= size) || (b < 0 || b >= size) then begin
          print_endline "Those coordinates are not in the board. \n"; set_ship n size track end
        else let ship = start_end_lst (x,y) (a,b) in
          if is_valid_ship ship track then
            if List.length ship = n then
              ship else begin print_endline "That ship isn't the right size. \n"; set_ship n size track end else begin
            print_endline "That ship overlaps with another ship. \n"; set_ship n size track end
      | exception BadCommand c -> print_endline "Not valid command. \n"; set_ship n size track
      | _ -> print_endline "Not valid command. \n"; set_ship n size track
    end

(** [auto_set_ship n size offset track] is a coordinate list of ship size [n] resulting from
    randomly generating coordinates with seed [offset]. The result is on board size [size]
    and doesn't overlap with any ships in [track]. *)
let rec auto_set_ship (n) (size) (offset) (track) : (int*int) list =
  Random.init offset; (*initialize the generator*)
  (*Generate initial points randomly *)
  let x = Random.int size in
  let y = Random.int size in
  let horiz = Random.bool () in
  let a_size = (n - 1) in
  (*need to add/sub n-1 from coord to get boat length of n.*)

  (*Generate endpoints smartly------------------------------------------------*)
  let (a,b) =
    (if (horiz = true) then
       (*Check which way boat can fit - to the left or right of (x,y)?*)
       if (x - a_size >= 0) then (x-a_size, y)
       else (x+a_size,y)
     else
       (*Check which way boat can fit - above or below (x,y)?*)
     if (y-a_size >= 0) then (x,y-a_size)
     else (x,y+a_size)) in

  if (x < 0 || x >= size) || (y < 0 || y >= size) || (a < 0 || a >= size) || (b < 0 || b >= size)
  then (auto_set_ship n size (offset + 3) track) (*previous steps should take care of *)
  else let ship = start_end_lst (x,y) (a,b) in
    (*Check if this ship overlaps old ship*)
    if is_valid_ship ship track then ship
    else (auto_set_ship n size (offset + 1) track)

(*overlap -> start over with new random points*)

(** [set_board config acc size] is a board with ships of lengths from [config]
    as chosen by the user and size [size]
    Requires:
    All elements of [config] are less than or equal to size. *)
let rec set_board (config: int list) (acc:(int*int) list list) (size:int) =
  match config with
  | [] -> Board.init size acc
  | h::t -> set_board t ((set_ship h size acc)::acc) size
(*TODO - modify this method so that you can get the computer to auto-set a ship.
  Possibly with boolean?
  Same as the above but with no prompts and you have to auto-gen the coords.*)

(** [auto_set_board config acc seed size] is a board with ships of lengths from [config]
    as chosen randomly by computer and size [size].  Requires:
    All elements of [config] are less than or equal to size. *)
let rec auto_set_board (config: int list) (acc:(int*int) list list) (seed:int) (size:int) =
  match config with
  | [] -> Board.init size acc
  | h::t -> auto_set_board t ((auto_set_ship h size seed acc)::acc) (seed + 20) size


(**[set_up_human name n cannons time config] sets up a Human player, creating the board
    based on configuration [config] and time [time] and assigning the player
   name [name]. Player has [cannons] cannons. *)
let rec set_up_human name n cannons radars time config=
  print_endline ("Would you like to create your own board? (Y/N)");
  print_string "> ";
  match read_line () with
  | "Y" | "y"-> (Player.init name (set_board config [] n) Player.Human cannons radars)
  | "N" | "n" -> let auto_bd = auto_set_board config [] time n in 
    Board.print_board_lst (Board.make_print_board (Board.coords_to_list auto_bd) n); Unix.sleep(5); print_string "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n";
    (Player.init name (auto_bd) Player.Human cannons radars)
  | _ -> print_endline ("Please enter Y or N"); set_up_human name n cannons radars time config






(** [make_players n time boards settings acc] is a list of [n] players
    with boards [boards], based on game settings [settings].
    It prompts the user to choose the name of each player.
    Requires: Time is a semi-random integer based on the current time.
    Raises: [Quit] if the player chooses to quit during it's execution. *)
let rec make_players (n:int) (time:int) (settings: settings) (acc:Player.t list) : Player.t list =
  if n = 0 then acc
  else
    (print_endline ("\nPlease enter the name of Player "^(string_of_int (3-n))^".");
     print_string  "> ";
     match read_line () with
     | name -> if (String.trim name) = "quit" then raise Quit else print_string "\n";
       print_endline ("Please enter the type of Player (Human, RandomAI, SmartAI, AdvancedAI): ");
       print_string "> ";
       let time2 = time + 1 in
       match read_line () with
       | pType -> let cannons = settings.cannons in
         if (String.trim name) = "quit" then raise Quit
         else if (String.lowercase_ascii (String.trim pType)) = "human" then (print_endline ""; make_players (n-1) time2 settings ((set_up_human name settings.size settings.cannons settings.radars time2 settings.config)::acc))
         else if (String.lowercase_ascii (String.trim pType)) = "randomai" then (print_endline ""; make_players (n-1) time2 settings ((Player.init name (auto_set_board settings.config [] (time2) settings.size) Player.RandomAI settings.cannons settings.radars)::acc))
         else if (String.lowercase_ascii (String.trim pType)) = "smartai" then (print_endline ""; make_players (n-1) time2 settings ((Player.init name (auto_set_board settings.config [] (time2) settings.size) Player.SmartAI settings.cannons settings.radars)::acc))
         else if (String.lowercase_ascii (String.trim pType)) = "advancedai" then (print_endline ""; make_players (n-1) time2 settings ((Player.init name (auto_set_board settings.config [] (time2) settings.size) Player.AdvancedAI settings.cannons settings.radars)::acc))
         else (print_endline "Not a valid player type\n"; make_players n time2 settings acc))

(** [make_opponents players] is a list with players. *)
let make_opponents (players: Player.t list)  =
  match players with
  |[] -> failwith "Not enough players"
  |p1::p2::[] -> (Player.set_opponent p1 p2)
  |_ -> failwith "Shouldn't get here"



(** [play_game init_players] is the game played between the players in
    [init_players]. *)
let rec play_game (init_players:Player.t list)=
  Random.init ((Unix.gettimeofday() |> int_of_float) mod 1000);
  let p_opponents = make_opponents init_players in
  let rec game (players: Player.t list) (acc: Player.t list) =
    match players with
    |[] -> game (List.rev acc) []
    |p::t -> let board = Player.get_board p in print_string "--------"; print_string (Player.get_name p); print_endline "'s turn-------\n";
      print_endline ((Player.get_name p)^"'s board:");
      Board.print_board (board);
      match Player.get_type p with
      |RandomAI ->
        (let c = (RandomAI.move (Player.get_board p)) in
         let move = RandomAI.select_hit c board p in
         match move with
         |None -> print_endline "Not valid\n"; game players acc
         |Some com -> (match com with
             |Hit coord -> let b = Board.hit c board in
               if Board.win b = false then match check_hit c board with
                 |true -> print_endline "\nYou hit a ship!"; print_endline ((Player.get_name p)^"'s board:"); Board.print_board b; Unix.sleep(3); game t ((Player.update_board p b)::acc)
                 |false -> print_endline "\nYou missed!\n"; print_endline ((Player.get_name p)^"'s board:"); Board.print_board b; print_string "\n \n \n";  Unix.sleep(3); game t ((Player.update_board p b)::acc)
               else  (print_string (Player.get_name p);
                      print_endline " has won the game!\n";Board.print_board (board); exit 0)
             |Cannon coord -> let b = Board.cannon_hit c board in
               if Board.win b = false then match check_cannon_hit c board with
                 |true -> print_endline "\nYou hit a ship!"; print_endline ((Player.get_name p)^"'s board:"); Board.print_board b; Unix.sleep(3); game t ((Player.update_board (Player.dec_cannons p) b)::acc)
                 |false -> print_endline "\nYou missed!\n"; print_endline ((Player.get_name p)^"'s board:"); Board.print_board b; print_string "\n \n \n";  Unix.sleep(3); game t ((Player.update_board (Player.dec_cannons p) b)::acc)
               else  (print_string (Player.get_name p);
                      print_endline " has won the game!\n"; Board.print_board (board); exit 0)
             |Place (x,y) -> print_endline "Not valid\n"; game players acc
             |Radar c -> game players acc
             |Score
             |Quit -> print_endline "Not valid\n"; game players acc ))
      |SmartAI ->
        (let c = (SmartAI.move (Player.get_board p)) in
         let move = SmartAI.select_hit c board p in
         match move with
         |None -> print_endline "Not valid\n"; game players acc
         |Some com -> (match com with
             |Hit coord -> let b = Board.hit c board in
               if Board.win b = false then match check_hit c board with
                 |true -> print_endline "\nYou hit a ship!"; print_endline ((Player.get_name p)^"'s board:"); Board.print_board b; (** Unix.sleep(3); *) game t ((Player.update_board p b)::acc)
                 |false -> print_endline "\nYou missed!\n"; print_endline ((Player.get_name p)^"'s board:"); Board.print_board b; print_string "\n \n \n";  (** Unix.sleep(3); *) game t ((Player.update_board p b)::acc)
               else  (print_string (Player.get_name p);
                      print_endline " has won the game!\n"; Board.print_board (board);exit 0)
             |Cannon coord -> let b = Board.cannon_hit c board in
               if Board.win b = false then match check_cannon_hit c board with
                 |true -> print_endline "\nYou hit a ship!"; print_endline ((Player.get_name p)^"'s board:"); Board.print_board b; (** Unix.sleep(3); *) game t ((Player.update_board (Player.dec_cannons p) b)::acc)
                 |false -> print_endline "\nYou missed!\n"; print_endline ((Player.get_name p)^"'s board:"); Board.print_board b; print_string "\n \n \n";  (** Unix.sleep(3); *) game t ((Player.update_board (Player.dec_cannons p) b)::acc)
               else  (print_string (Player.get_name p);
                      print_endline " has won the game!\n";Board.print_board (board); exit 0)
             |Place (x,y) -> print_endline "Not valid\n"; game players acc
             |Radar c -> game players acc
             |Score
             |Quit -> print_endline "Not valid\n"; game players acc ))
      |AdvancedAI ->
        (let c = (AdvancedAI.move (Player.get_board p)) in
         let move = AdvancedAI.select_hit c board p in
         match move with
         |None -> print_endline "Not valid\n"; game players acc
         |Some com -> (match com with
             |Hit coord -> let b = Board.hit c board in
               if Board.win b = false then match check_hit c board with
                 |true -> print_endline "\nYou hit a ship!"; print_endline ((Player.get_name p)^"'s board:"); Board.print_board b; (** Unix.sleep(3); *) game t ((Player.update_board p b)::acc)
                 |false -> print_endline "\nYou missed!\n"; print_endline ((Player.get_name p)^"'s board:"); Board.print_board b; print_string "\n \n \n";  (** Unix.sleep(3); *) game t ((Player.update_board p b)::acc)
               else  (print_string (Player.get_name p);
                      print_endline " has won the game!\n"; Board.print_board (board);exit 0)
             |Cannon coord -> let b = Board.cannon_hit c board in
               if Board.win b = false then match check_cannon_hit c board with
                 |true -> print_endline "\nYou hit a ship!"; print_endline ((Player.get_name p)^"'s board:"); Board.print_board b; (** Unix.sleep(3); *) game t ((Player.update_board (Player.dec_cannons p) b)::acc)
                 |false -> print_endline "\nYou missed!\n"; print_endline ((Player.get_name p)^"'s board:"); Board.print_board b; print_string "\n \n \n";  (** Unix.sleep(3); *) game t ((Player.update_board (Player.dec_cannons p) b)::acc)
               else  (print_string (Player.get_name p);
                      print_endline " has won the game!\n";Board.print_board (board); exit 0)
             |Place (x,y) -> print_endline "Not valid\n"; game players acc
             |Radar c -> game players acc
             |Score
             |Quit -> print_endline "Not valid\n"; game players acc ))
      |Human ->
        (print_endline ("\n Type a command "^(Player.get_name p));
         print_endline ("\n You have "^(p|>Player.get_cannons|>string_of_int)^" 3x3 cannons left and "^(p |> Player.get_radars |> string_of_int)^" 3x3 radars left.");
         print_string  "> ";
         match read_line () with
         | exception End_of_file -> print_endline "Not valid\n"; game players acc
         | s -> match parse s with
           | exception (BadCommand c) -> print_endline "\nNot a valid command\n"; game players acc
           |Place (x,y) -> print_endline "Not valid\n"; game players acc
           |Hit c -> let b = Board.hit c board in
             if Board.win b = false then match check_hit c board with
               |true -> print_endline "\nYou hit a ship!"; print_endline ((Player.get_name p)^"'s board:"); Board.print_board b; game t ((Player.update_board p b)::acc)
               |false -> print_endline "\nYou missed!\n";print_endline ((Player.get_name p)^"'s board:"); Board.print_board b; print_string "\n \n \n"; game t ((Player.update_board p b)::acc)
             else  (print_string (Player.get_name p);
                    print_endline " has won the game!\n"; Board.print_board (board);exit 0)
           |Cannon c -> if Player.get_cannons p > 0 then let b = Board.cannon_hit c board in
               if Board.win b = false then match check_hit c board with
                 |true -> print_endline "\nYou hit a ship!"; print_endline ((Player.get_name p)^"'s board:"); Board.print_board b; game t ((Player.update_board (Player.dec_cannons p) b)::acc)
                 |false -> print_endline "\nYou missed!\n";print_endline ((Player.get_name p)^"'s board:"); Board.print_board b; print_string "\n \n \n"; game t ((Player.update_board (Player.dec_cannons p) b)::acc)
               else  (print_string (Player.get_name p);
                      print_endline " has won the game!\n"; Board.print_board (board);exit 0)
             else print_endline "\nYou don't have any cannons left!"; game players acc
           | Radar c -> if (Player.get_radars p) > 0 then begin  Board.print_radar (Player.get_board p) c; game ((Player.dec_radar p)::t) acc end 
             else print_endline "\nYou don't have any radars left!"; game players acc
           |Score -> print_string "Your score: "; print_int (Board.score board); print_string "\n";
             print_string "Opponent Score: "; print_int (Board.score (Player.get_board (List.hd t))); print_string "\n"; game players acc
           |Quit ->  exit 0) in game p_opponents []

(**[generate_configuration num_ships size acc] generates a random configuration of
   ship lengths with length [num_ships], the number of ships.
   [size] is the dimensions of the board. E.g. a 5x5 board has [size] = 5.
   Requires: [num_ships] is an integer greater than 0.
   Requires: [acc] is [].*)
let rec generate_configuration num_ships size acc =
  if (num_ships = 0) then acc else
    (*Generate a ship length of max length size*)
    let nxt = Random.int (size) in
    let nxt_2 = if (nxt > (size / 2)) then (nxt/2) else nxt in
    (generate_configuration (num_ships - 1) size ([nxt_2]@acc))

(**[set_settings time] prompts for the settings the user wants for the given game.*)
let rec set_settings (time:int) : settings = (*TODO allow prompting*)
  (*setting up default settings*)
  let default_config = [2;2;3;4;5] in
  let default_size = 10 in
  let default_cannons = 2 in
  let default_radars = 2 in 

  print_endline ("Do you want to use default settings? (Y/N)");
  print_string  "> ";
  match read_line () with
  | "Y" | "y" -> {config = default_config;
                  size = default_size;
                  cannons = default_cannons;
                  radars = default_radars}
  | "N" | "n" -> (
      print_endline ("Okay. How big should the board be? Enter a number between 5 and 50");
      print_string "> ";
      let size_board =  (
        match read_line () |> int_of_string with
        | x-> (if (x >= 5 && x <= 50) then x
               else (print_endline ("Invalid number of ships. Using default.");
                     default_size))) in
      print_endline ("The board is "^(string_of_int size_board)^" by "^(string_of_int size_board));

      print_endline ("How many cannons should there be? Enter a number between 0 and 5.");
      print_string "> ";
      let num_cannons = (
        match read_line () |> int_of_string with
        | x-> (if (x >= 0 && x <= 5) then x
               else (print_endline ("Invalid number of cannons. Using default.");
                     default_cannons))) in
      print_endline ("There are "^(string_of_int num_cannons)^" cannons.");


      print_endline ("How many radars should there be? Enter a number between 0 and 5.");
      print_string "> ";
      let num_radar = (
        match read_line () |> int_of_string with
        | x-> (if (x >= 0 && x <= 5) then x
               else (print_endline ("Invalid number of radars. Using default.");
                     default_radars))) in
      print_endline ("There are "^(string_of_int num_radar)^" radars.");


      print_endline ("How many ships should there be? Enter a number between 2 and 20.");
      print_string "> ";
      let num_ships = (
        match read_line () |> int_of_string with
        | x-> (if (x >= 2 && x <= 20) then x
               else (print_endline ("Invalid number of ships. Using default.");
                     List.length default_config))) in
      print_endline ("There are "^(string_of_int num_ships)^" ships.");

      print_endline ("Now generating a random configuration of ships...");
      let config = (
        Random.init time;
        generate_configuration num_ships size_board []
      ) in
      print_endline ("Done.");

      (*Return the custom settings*)
      {config = config;
       size = size_board;
       cannons = num_cannons;
       radars = num_radar}
    )
  | _ -> print_endline ("Invalid answer. Try again"); set_settings time

(** [main ()] prompts for the game to play, sets up the players, and then starts
    the game. *)
let main () =
  print_endline "\n\nWelcome to Battleship!\n";
  print_endline "You're in 2-player mode. \n";
  print_endline ("Play the game by placing ships on the board, then taking turns " ^
                 "trying to hit each other's ships. You get points by sinking a ship. First player " ^
                 "to sink all of their opponent's ships wins! \n");
  (*get the current time of day to use as a random seed for the boat generation*)
  let time = (Unix.gettimeofday() |> int_of_float) mod 1000 in
  print_endline ("Game settings:");
  let settings = set_settings time in
  match (List.rev (make_players (2) time settings [])) with
  | exception Quit -> ()
  | x -> (play_game x)

(* Execute the game engine. *)
let () = main ()
